import os
os.chdir('bindings/python')
execfile('setup.py')
