#include <iostream>

#include "problemsolver.h"

using std::cin;
using std::cout;
using std::endl;

int main()
{
    ProblemSolver solver;

    solver.solveProblem();

    return 0;
}
